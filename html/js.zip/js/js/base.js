//#region mi codigo
  window.addEventListener("load",inicio);
  window.addEventListener("load",mi_inicio);


  function mi_inicio()
  {
    document.getElementById("cuadrado").addEventListener("click",ccuadrado);
  document.getElementById("circulo").addEventListener("click",ccirculo);
  document.getElementById("limpiar").addEventListener("click",limpiar);
  }

  function ccirculo()
  {
    document.getElementById("circulof").innerHTML="<div id='lcir' class='fcir'><p>CIRCULO</p></div>";
  }
  function ccuadrado(){
    document.getElementById("cuadradof").innerHTML="<div id='lcua' class='fcua'><p>CUADRADO</p></div>";
 }

 function limpiar()
 {
   document.getElementById("lcir").className="";
   document.getElementById("lcir").innerHTML=""
   document.getElementById("lcua").className="";
   document.getElementById("lcua").innerHTML=""
 }
  //#endregion
//#region funciones documento
  function inicio()
  {
    document.getElementById("cambiartexto").addEventListener("click",cambiartext);
    document.getElementById("cambiarclase").addEventListener("click",cambiarclase);
    document.getElementById("quitarclase").addEventListener("click",quitarclase)
  }

  function cambiartext()
  {
    document.getElementById("p1").innerHTML="primer parrafo cambiardo";
    document.getElementsByTagName("p")[1].innerHTML="segundo parrafo cambiado";
    document.getElementsByClassName("miClase")[0].innerHTML="tercer parrafo cambiado";
  }

  function cambiarclase()
  {
    document.getElementById("p1").setAttribute("class","");
    document.getElementById("p2").className="miClase1";
    document.getElementById("p3").className="miClase1";

  }

  function quitarclase()
  {
    document.getElementById("p1").setAttribute("class","");
    document.getElementById("p2").className="";
    document.getElementById("p3").className="";

  }
  //#endregion

